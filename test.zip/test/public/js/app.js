import web3 from 'web3';
import {React, Component} from 'react';
import ReactDOM from 'react-dom';
import COIN_DISTRIBUTION from 'data.js';

export class App extends React.Component {
    constructor() {
        this.initWeb3();
    }

    componentDidMount() {
        this.initWeb3();
    }

    initWeb3() {
        this.web3 = new web3(new web3.providers.HttpProvider(""));
        this.opuAbi = '';
        this.opuAddress = '0x65e3c4a750a2e7cc7cce86d01587bbcbbe99042e';
        web3.eth.defaultAccount = web3.eth.accounts[0];
    }

    getAddress() {
    }

    renderTable() {
        var html = '<table><thead>';
        let headers = COIN_DISTRIBUTION.table.headers.map(header => {
            return '<th>{{header}}</th>';
        })
        html += '</thead><tbody>';

        let headers = COIN_DISTRIBUTION.table.headers.map(row => {
            return '<tr>{{row}}</tr>';
        })

        html += '</tbody></table>'

        return html;
    }

    render() {
        return (
            '<div> Opu Dashboard' + 
            '<button onclick="getAddress()"/>Get Address</button>' +
            '<h2>Overall Allocation</h2>' +
            renderTable() +
            '</div>'
        )
    }
}