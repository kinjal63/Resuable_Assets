module.exports = {
    COIN_DISTRIBUTION: {
        "table": {
            "headers": ["Minted", "Issued", "Restrictions"],
            "rows": [
                {
                    "data": ["Public","550,000,000", "78,391,489", "Available on Opu Marketplace"]
                },
                {
                    "data": ["Team & Founders","550,000,000", "452,933,177", "Locked until 12/19/2019 Monthly Vesting thru 12/20/2020"]
                },
                {
                    "data": ["Partners","175,000,000", "150,137,025", "Available on Opu Marketplace"]
                },
                {
                    "data": ["Rewards","150,000,000", "84,887,735", "Available on Opu Marketplace"]
                },
                {
                    "data": ["Cold Storage (12/19/2020)","75,000,000", "0", "Locked thru 12/20/2020"]
                }
            ]
        }
    }
}