import {App} from 'js/app.js';
import ReactDOM from 'react-dom';

ReactDOM.render(<App />, div || document.getElementById('dashboard'));