import React from 'react';
import { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { userActions } from '../actions';

class RegisterPage extends Component {
    constructor(props) {
        super(props);

        this.state = {
            user: {
                username: '',
                password: ''
            },
            submitted: false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

        userActions.register.bind(this);
    }

    handleChange(event) {
        const user = {...this.state.user};
        if(event.target.name === 'username') {
            user.username = event.target.value;
            this.setState({user});
        }
        else if(event.target.name === 'password') {
            user.password = event.target.value;
            this.setState({user});
        }

        console.log(this.state);
    }

    handleSubmit(event) {
        this.setState({submitted: true})
        
        this.props.register(false, '');
        if(this.state.user.username.length > 0 && this.state.user.password.length > 0) {
            const registerReq = userActions.register(this.state.user);
            registerReq.then(action => {
                this.props.dispatch(action);
                this.props.register(true, 'User registered succesfully');
            }).catch(error => {
                this.props.dispatch(error);
                this.props.register(false, error.error);
            })
        }

        event.preventDefault();
    }

    render() {
        const { user, submitted } = this.state;
        return (
            <div className="col-md-6 col-md-offset-3">
            
                <h2>Register</h2>
                <form name="form">
                    <div className={'form-group' + (submitted && !user.username ? ' has-error' : '')}>
                        <label htmlFor="username">Username</label>
                        <input type="text" onChange={this.handleChange.bind(this)} 
                            className="form-control username" name="username" />
                        {submitted && !user.username &&
                            <div className="help-block">Username is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !user.password ? ' has-error' : '')}>
                        <label htmlFor="password">Password</label>
                        <input type="password" onChange={this.handleChange.bind(this)} 
                            className="form-control" name="password"/>
                        {submitted && !user.password &&
                            <div className="help-block">Password is required</div>
                        }
                    </div>
                    <div className="form-group">
                        <button className="btn btn-primary" onClick={this.handleSubmit.bind(this)}>Register</button>
                        <Link to="/login" className="btn btn-link">Cancel</Link>
                    </div>
                </form>
            </div>
        );
    }
}

// complete the below function
function mapStateToProps(state) {
    return {
        ...state
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch: dispatch
    }
}

const ConnectedComponent = connect(mapStateToProps, mapDispatchToProps)(RegisterPage);
export {ConnectedComponent as RegisterPage};
// export {ConnectedComponent as TestRegisterPage};
