import React from 'react';
import { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import { BrowserHistory } from 'react-router';
import { connect } from 'react-redux';

import { userActions } from '../actions';

class LoginPage extends Component {
    constructor(props, context) {
        super(props, context);

        // reset login status

        this.state = {
            username: '',
            password: '',
            submitted: false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

        userActions.login.bind(this);        
    }

    handleChange(e) {
        const val = e.target.value;
        if(e.target.name === 'username')
            this.setState((prevState) => {
                return {
                    ...prevState,
                    username: val
                }
            })
        else if(e.target.name === 'password')
            this.setState((prevState) => {
                return {
                    ...prevState,
                    password: val
                }
            })

        console.log(this.state);
    }

    handleSubmit(e) {
        this.setState({submitted: true});

        this.props.login(false, '');
        if(this.state.username.length > 0 && this.state.password.length > 0) {
            const loginReq = userActions.login(this.state.username, this.state.password);
            loginReq.then(response => {
                this.props.dispatch(response);
                this.context.router.history.push("/")
            }).catch(error => {
                this.props.dispatch(error);
                this.props.login(false, 'Error: ' + error.error);
            })
        }
        e.preventDefault();
    }

    render() {
        // <NavLink to="/" 
        const { username, password, submitted } = this.state;
        return (
            <div className="col-md-6 col-md-offset-3">

                <h2>Login</h2>

                <form name="form">
                    <div className={'form-group' + (submitted && !username ? ' has-error' : '')}>
                        <label htmlFor="username">Username</label>
                        <input type="text" className="form-control username" name="username"
                            onChange={this.handleChange} />
                        {submitted && !username &&
                            <div className="help-block">Username is required</div>
                        }
                    </div>
                    <div className={'form-group' + (submitted && !password ? ' has-error' : '')}>
                        <label htmlFor="password">Password</label>
                        <input type="password" className="form-control" name="password"
                            onChange={this.handleChange}/>
                        {submitted && !password &&
                            <div className="help-block">Password is required</div>
                        }
                    </div>
                    <div className="form-group">
                        <button className="btn btn-primary" onClick={(e) => this.handleSubmit(e)}>Login</button>
                        {/* <div class="spinner-border" role="status">
                            <span class="sr-only">Loading...</span>
                        </div> */}
                        <Link to="/register" className="btn btn-link">Register</Link>
                    </div>

                </form>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        authentication: state.authentication
    }
}

function mapDispatchToProps(dispatch) {
    console.log(dispatch);
    return {
        dispatch: dispatch
    }
}

const ConnectedComponent = connect(mapStateToProps)(LoginPage);
export {ConnectedComponent as LoginPage};
// export {ConnectedComponent as TestLoginPage};
