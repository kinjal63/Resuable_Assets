import React from 'react';
import { BrowserRouter as Router, Route, Redirect  } from 'react-router-dom';
import { connect } from 'react-redux';
import { PrivateRoute } from './PrivateRoute.js';
import { history } from './helpers';
import { alertActions } from './actions';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { RegisterPage } from './components/RegisterPage';

class App extends React.Component {
    constructor(props) {
        super(props);
        console.log('props' + props);

        const { dispatch } = this.props;
        history.listen((location, action) => {
            console.log(location + ',' + action);
        });
    }

    alertEvent = (isSuccess, message) => {
        this.props.dispatch(alertActions.clear());
        if(isSuccess) {
            this.props.dispatch(alertActions.success(message))
        }
        else {
            if(message.length > 0) {
                this.props.dispatch(alertActions.error(message))
            }
            else {
                this.props.dispatch(alertActions.clear())
            }
        }
    }

    render() {
        const { alert } = this.props;        
        return (
            <div className="container">
                <Router>
                    <div className="col-sm-8 col-sm-offset-2">
                        <Route path="/" exact strict render={() => {
                            return (this.props.loggedIn ? <HomePage /> : <Redirect to="/login" />)
                        }}/>

                        {alert != undefined && Object.entries(alert).length > 0 ?
                            (<div className={alert.type === 'alert-success' ? 'alert alert-success' : 
                                    alert.type === 'alert-danger' ? 'alert alert-danger' : ''}>
                                {alert.message}
                            </div>)
                            : ''}

                        <Route path="/login" exact strict render={() => {
                            return <LoginPage login={this.alertEvent} />
                        }} />
                        <Route path="/register" exact strict render={() => {
                            return <RegisterPage register={this.alertEvent} />
                        }} />
                    </div>
                </Router>
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { alert } = state;
    console.log(alert);
    return {
        alert
    };
}

function mapDispatchToProps(dispatch) {
    return {
        dispatch
    }
}

const connectedComponent = connect(mapStateToProps, mapDispatchToProps)(App);
export {connectedComponent as App};