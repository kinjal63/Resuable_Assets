package com.hackerrank.github.repository;

public interface EventRepository {
}
