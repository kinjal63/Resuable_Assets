package com.hackerrank.github.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class GithubApiRestController {
}
