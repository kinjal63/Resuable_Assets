package com.kinjal.todo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kinjal.todo.request.entity.UserRequest;
import com.kinjal.todo.response.entity.GenericResponse;
import com.kinjal.todo.response.entity.ResponseCode;
import com.kinjal.todo.response.entity.UserResponse;
import com.kinjal.todo.service.UserService;

public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping(value="/login", consumes="application/json", produces="application/json")
	@ResponseBody
	public ResponseEntity<GenericResponse> login(@RequestBody UserRequest user) {
		String token = userService.login(user);
		
		ResponseCode resCode = ResponseCode.USER_LOGIN_SUCCESS;
		if(StringUtils.isEmpty(token)) {
			resCode = ResponseCode.TODO_CREATION_FAILED;
		}
		return new ResponseEntity<GenericResponse>(new UserResponse(resCode.getCode(), resCode.getMessage(), token), HttpStatus.OK);
	}
}
