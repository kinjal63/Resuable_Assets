package com.kinjal.todo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.kinjal.todo.domain.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
	User findByUsernameAndPassword(String userName, String password);

}
