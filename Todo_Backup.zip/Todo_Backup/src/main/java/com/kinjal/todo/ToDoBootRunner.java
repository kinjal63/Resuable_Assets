package com.kinjal.todo;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.kinjal.todo.domain.Todo;
import com.kinjal.todo.domain.User;
import com.kinjal.todo.repository.TodoRepository;

@Component
public class ToDoBootRunner implements CommandLineRunner {
	@Autowired
	private TodoRepository todoRepository;
	
	public void run(String... args) throws Exception {
		Todo todo = new Todo("Test ToDo", "Test description todo", new Date());
		todo.setUser(new User("test", "password"));
		todoRepository.save(todo);
		
		System.out.println("saved in DB");
	}
}
