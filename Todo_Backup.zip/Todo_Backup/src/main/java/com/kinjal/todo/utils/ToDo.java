package com.kinjal.todo.utils;

public class ToDo {
	public interface Database {
		static String CATALOG_NAME = "db_catalog";
	}
}
