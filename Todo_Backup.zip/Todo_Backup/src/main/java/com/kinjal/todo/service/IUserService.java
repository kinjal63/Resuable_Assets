package com.kinjal.todo.service;

import com.kinjal.todo.request.entity.UserRequest;

public interface IUserService {
	String login(UserRequest user);
}
