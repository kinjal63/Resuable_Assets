package com.kinjal.todo.domain;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.kinjal.todo.utils.ToDo;

import lombok.Data;
import lombok.NonNull;

@Entity
//@Table(catalog=ToDo.Database.CATALOG_NAME)
@Data
public class Todo {
	@Id
	@GeneratedValue
	private Long id;
	private @NonNull String title;
	private @NonNull String description;
	private @NonNull Date updatedAt;
	
	@ManyToOne(cascade=CascadeType.PERSIST)
	private User user;
}
