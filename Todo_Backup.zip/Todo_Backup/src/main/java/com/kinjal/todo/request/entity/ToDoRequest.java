package com.kinjal.todo.request.entity;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

@JsonInclude(value=Include.NON_NULL)
@Data
public class ToDoRequest {	
	private Long id;
	private String title;
	private String description;
	private Long userId;
}
