package com.kinjal.todo.service;

import org.springframework.beans.factory.annotation.Autowired;
import com.kinjal.todo.domain.User;
import com.kinjal.todo.repository.UserRepository;
import com.kinjal.todo.request.entity.UserRequest;
import com.kinjal.todo.utils.TokenUtil;

public class UserService implements IUserService {
	@Autowired
	UserRepository userRepository;
	
	@Override
	public String login(UserRequest user) {
		User u = userRepository.findByUsernameAndPassword(user.getUserId(), user.getPassword());
		if(u != null) {
			return generateToken(u);
		}
		return null;
	}
	
	private String generateToken(User u) {
		return TokenUtil.generateToken(u);
	}
}
