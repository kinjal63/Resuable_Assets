package com.kinjal.todo.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kinjal.todo.domain.Todo;
import com.kinjal.todo.repository.TodoRepository;
import com.kinjal.todo.request.entity.ToDoRequest;

@Service
public class TodoService implements IToDoService {
	@Autowired
	private TodoRepository todoRepository;

	@Override
	public Long addOrUpdateTodo(ToDoRequest todo) {
		Todo todoObj = todoRepository.save(new Todo(todo.getTitle(), todo.getDescription(), new Date()));
		return todoObj != null ? todo.getId() : -1;
	}

	@Override
	public boolean removeToDo(Long id) {
		if(!todoRepository.existsById(id)) {
			return false;
		}
		todoRepository.deleteById(id);
		return true;
	}	
}
