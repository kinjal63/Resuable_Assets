package com.kinjal.todo.service;

import com.kinjal.todo.request.entity.ToDoRequest;

public interface IToDoService {	
	Long addOrUpdateTodo(ToDoRequest todo);
	boolean removeToDo(Long id);
}
