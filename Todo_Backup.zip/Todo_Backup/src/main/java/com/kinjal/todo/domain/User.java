package com.kinjal.todo.domain;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.kinjal.todo.utils.ToDo;

import lombok.Data;
import lombok.NonNull;

@Entity
//@Table(catalog=ToDo.Database.CATALOG_NAME)
@Data
public class User {
	@Id
	@GeneratedValue
	private Long id;
	private @NonNull String userId;
	private @NonNull String password;
	
	@OneToMany(mappedBy="user")
	private List<Todo> todoList;
	
	public User(String userId, String password) {
		this.userId = userId;
		this.password = password;
	}
}
