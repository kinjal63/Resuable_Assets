package com.kinjal.todo.response.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.NonNull;

@JsonInclude(value=Include.NON_NULL)
@Data
public class GenericResponse {
	private @NonNull Integer resCode;
	private @NonNull String message;
}
