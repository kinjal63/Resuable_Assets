package com.kinjal.todo.respository;

import org.springframework.data.repository.CrudRepository;
import com.kinjal.todo.domain.Todo;

public interface TodoRepository extends CrudRepository<Todo, Long> {

}
