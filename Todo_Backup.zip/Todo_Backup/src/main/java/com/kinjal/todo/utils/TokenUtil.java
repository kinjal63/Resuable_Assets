package com.kinjal.todo.utils;

import java.util.Date;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.kinjal.todo.domain.User;

import io.jsonwebtoken.impl.TextCodec;

public class TokenUtil {
	private static String secret = "kinjal_todo_delloite";
	
	public static String generateToken(User user) {
		String token = null;
		try {
		    Algorithm algorithm = Algorithm.HMAC256(secret);
		    token = JWT.create()
		        .withIssuer("todo_" + user)
		        .withExpiresAt(new Date(System.currentTimeMillis() + 3600 * 1000))
		        .sign(algorithm);
		} catch (JWTCreationException exception){
		    return null;
		}
		return token;
	}
	
	public static boolean verifyToken(String token) {
		boolean isVerified = false;
		try {
		    Algorithm algorithm = null;
		    
			algorithm = Algorithm.HMAC256(TextCodec.BASE64URL.decode(secret));
		    JWTVerifier verifier = JWT.require(algorithm)
		    	.acceptLeeway(1)
		        .build();
		    DecodedJWT dJwt = verifier.verify(token);
		    
		    System.out.println("Issuer:" + dJwt.getIssuer() + ", Audience:" + dJwt.getAudience() + ", Issued At:" + dJwt.getIssuedAt());
		    if(dJwt != null)
		    	isVerified = true;
		    
		} catch (JWTVerificationException exception){
			isVerified = false;
		    exception.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isVerified;
	}
}
