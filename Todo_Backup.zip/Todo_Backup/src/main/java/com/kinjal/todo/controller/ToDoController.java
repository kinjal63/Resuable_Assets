package com.kinjal.todo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kinjal.todo.request.entity.ToDoRequest;
import com.kinjal.todo.response.entity.GenericResponse;
import com.kinjal.todo.response.entity.ResponseCode;
import com.kinjal.todo.service.TodoService;

@Controller
public class ToDoController {
	@Autowired
	private TodoService toDoservice;

	@PostMapping(value="/addTodo", consumes="application/json", produces="application/json")
	@ResponseBody
	public ResponseEntity<GenericResponse> addToDO(@RequestBody ToDoRequest todo) {
		long id = toDoservice.addOrUpdateTodo(todo);
		ResponseCode resCode = ResponseCode.TODO_CREATED;
		if(id != -1) {
			resCode = ResponseCode.TODO_CREATION_FAILED;
		}
		return new ResponseEntity<GenericResponse>(new GenericResponse(resCode.getCode(), resCode.getMessage()), HttpStatus.OK);
	}
	
	@PostMapping(value="/addTodo", consumes="application/json", produces="application/json")
	@ResponseBody
	public ResponseEntity<GenericResponse> updateToDO(@RequestBody ToDoRequest todo) {
		long id = toDoservice.addOrUpdateTodo(todo);
		ResponseCode resCode = ResponseCode.TODO_UPDATED;
		if(id != -1) {
			resCode = ResponseCode.TODO_UPDATE_FAILED;
		}
		return new ResponseEntity<GenericResponse>(new GenericResponse(resCode.getCode(), resCode.getMessage()), HttpStatus.OK);
	}
	
	@GetMapping(value="/addTodo")
	@ResponseBody
	public ResponseEntity<GenericResponse> removeToDO(@RequestParam("todo_id") Long id) {
		boolean isRemoved = toDoservice.removeToDo(id);
		ResponseCode resCode = ResponseCode.TODO_REMOVED;
		if(!isRemoved) {
			resCode = ResponseCode.TODO_REMOVE_FAILED;
		}
		return new ResponseEntity<GenericResponse>(new GenericResponse(resCode.getCode(), resCode.getMessage()), HttpStatus.OK);
	}
	
	@RequestMapping(value="/")
	public String display() {
		return "index";
	}
}
