package com.kinjal.todo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kinjal.todo.request.entity.ToDoRequest;

@Controller
public class ToDoController {

	@GetMapping(value="/addTodo")
	@ResponseBody
	public ResponseEntity addToDO(@RequestBody ToDoRequest todo) {
		return ResponseEntity.ok(HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/")
	public String display() {
		return "index";
	}
}
