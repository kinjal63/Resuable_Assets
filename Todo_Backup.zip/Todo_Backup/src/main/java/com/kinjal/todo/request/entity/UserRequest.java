package com.kinjal.todo.request.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NonNull;

@Data
@JsonInclude(content=Include.NON_NULL)
public class UserRequest {
	
	private @NonNull String userId;
	private @NonNull String password;
}
