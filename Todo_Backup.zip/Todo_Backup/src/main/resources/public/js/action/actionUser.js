import { TYPE_USER, TYPE_CURRENT_LOGGED_IN_USER } from "../utils/constants";

export const addUser = (userObj) => { 
    return async (dispatch, userObj) => {
        dispatch({
            type: TYPE_USER,
            data: userObj
        });
    }
}

export const currentUserLoggedIn = (userObj) => { 
    return async (dispatch, userObj) => {
        dispatch({
            type: TYPE_CURRENT_LOGGED_IN_USER,
            data: userObj
        });
    }
}

