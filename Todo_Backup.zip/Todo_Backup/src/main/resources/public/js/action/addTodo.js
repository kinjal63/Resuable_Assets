import { TYPE_ADD_TODO } from "../utils/constants";

const addToDo = async (dispatch, toDoObj) => {
    return dispatch({
        type: TYPE_ADD_TODO,
        data: toDoObj
    })
}