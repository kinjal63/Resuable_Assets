import { TYPE_ADD_TODO, TYPE_REMOVE_TODO } from "../utils/constants";

export const addToDo = (toDoObj) => {
    return dispatch => {
        dispatch({ 
            type: TYPE_ADD_TODO,
            data: toDoObj
        })
    }
}

export const removeToDo = (id) => {
    return dispatch => {
        dispatch({
            type: TYPE_REMOVE_TODO,
            data: id
        })
    }
}