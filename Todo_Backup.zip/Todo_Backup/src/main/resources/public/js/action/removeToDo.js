import { TYPE_REMOVE_TODO } from "../utils/constants";

const removeToDo = async (dispatch, id) => {
    return dispatch({
        type: TYPE_REMOVE_TODO,
        data: id
    })
}