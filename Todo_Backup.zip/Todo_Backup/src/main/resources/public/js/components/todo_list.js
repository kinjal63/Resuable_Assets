import React, {Component} from 'react';
import {connect} from 'react-redux';
import {todos} from '../reducer/reducer';
import { addToDo, removeToDo } from '../action/actionTodo';

class ToDoList extends Component {
    componentDidMount() {
        console.log('rendered TodoList');        

        this.props.addToDo({
            id: 1,
            title: 'To Do 1',
            description: 'Des 1',
            updatedAt: '10 minutes ago'
        })

        this.props.addToDo({
            id: 2,
            title: 'To Do 2',
            description: 'Des 1',
            updatedAt: '10 minutes ago'
        })

        this.props.addToDo({
            id: 3,
            title: 'To Do 3',
            description: 'Des 1',
            updatedAt: '10 minutes ago'
        })
    }

    renderTodoList() {
        console.log(this.props.todoList);

        // return <ul className="ui relaxed divided list">
        var list = this.props.todoList.map((todo) => {
                console.log(todo.title);
                return (
                    
                    <div key={todo.id} className="ui relaxed divided list">
                        <div className="item">
                            <i className="large github middle aligned icon"></i>
                            <div className="content">
                                <a className="header">{todo.title}</a>
                            <div className="description">{todo.updatedAt}</div>
                            </div>
                        </div>
                    </div>
                )
            });        

        console.log(list);
        return list;
    }

    render() {
        return this.renderTodoList()
            // <div className="ui relaxed divided list">
            //     <div className="item">
            //         <i className="large github middle aligned icon"></i>
            //         <div className="content">
            //         <a className="header">Semantic-Org/Semantic-UI</a>
            //         <div className="description">Updated 10 mins ago</div>
            //         </div>
            //     </div>
            //     <div className="item">
            //         <i className="large github middle aligned icon"></i>
            //         <div className="content">
            //         <a className="header">Semantic-Org/Semantic-UI-Docs</a>
            //         <div className="description">Updated 22 mins ago</div>
            //         </div>
            //     </div>
            //     <div className="item">
            //         <i className="large github middle aligned icon"></i>
            //         <div className="content">
            //         <a className="header">Semantic-Org/Semantic-UI-Meteor</a>
            //         <div className="description">Updated 34 mins ago</div>
            //         </div>
            //     </div>
            // </div>
    }
}

const mapStateToProps = (state) => {
    console.log(state);    
    return state;
}

const mapDispatchToProps = (dispatch) => {
    addToDo: () => dispatch({type: TYPE_ADD_TODO, data:'123'}),
    removeToDo
}
export default connect(mapStateToProps, {addToDo})(ToDoList);