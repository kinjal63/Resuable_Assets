import React, {Component} from 'react';
import ReactDOM from 'react-dom';

const App = ()=> {
	console.log('rendering now1525612');
	return (
		<div>Test ToDo11123456789101112</div>
	)
}

ReactDOM.render(
	<App />,
	document.getElementById('root')
)

